
<?php
$servername = 'localhost';
$username = 'root';
$password = 'CP}>}o40PYqSX*~Y';
$dbname = 'classroom';

$conn = new mysqli($servername, $username, $password, $dbname) ;




?>
