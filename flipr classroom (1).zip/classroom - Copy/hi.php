<!DOCTYPE html>
<html>
<head>
   
    <title>Document</title>
</head>
<body>
    <form method="POST" action="signin1.php">
        <input id="name"></input>
        <input id="email"></input>
        <input id="password"></input>
        <input type="submit">
    </form>
</body>
</html>